const {
  Dialog,
  Box,
  Typography,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  IconButton,
  Avatar,
  Divider,
  Button,
  TextField
} = MaterialUI;
const {
  useState,
  useEffect,
  useContext
} = React;
import { Context } from "../cd073e99-961c-4d8f-a678-bc0a129dfe7e.js";
import { post } from "../f5c5ef00-6be3-4376-b8d0-39269589155d.js";
export function AccountSettingsDialog({
  open,
  onClose
}) {
  const {
    user
  } = useContext(Context);
  const [activeMenu, setActiveMenu] = useState("Account");
  const menuItems = [{
    label: "Account",
    icon: /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded"
    }, "person"),
    active: true
  }, {
    label: "Sessions",
    icon: /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded"
    }, "laptop_mac")
  }, {
    label: "Appearance",
    icon: /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded"
    }, "palette")
  }, {
    label: "Notifications",
    icon: /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded"
    }, "notifications")
  }, {
    label: "Preferences",
    icon: /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded"
    }, "tune")
  }, {
    label: "Keyboard",
    icon: /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded"
    }, "keyboard")
  }, {
    label: "Sidebar",
    icon: /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded"
    }, "view_sidebar")
  }, {
    label: "Voice & Video",
    icon: /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded"
    }, "mic")
  }, {
    label: "Security & Privacy",
    icon: /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded"
    }, "security")
  }, {
    label: "Encryption",
    icon: /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded"
    }, "lock")
  }, {
    label: "Labs",
    icon: /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded"
    }, "science")
  }, {
    label: "Help & About",
    icon: /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded"
    }, "help_outline")
  }];
  return /*#__PURE__*/React.createElement(Dialog, {
    open: open,
    onClose: onClose,
    maxWidth: "md",
    fullWidth: true
  }, /*#__PURE__*/React.createElement(Box, {
    sx: {
      display: "flex",
      height: 600
    }
  }, /*#__PURE__*/React.createElement(Box, {
    sx: {
      width: 240,
      borderRight: "1px solid #e0e0e0",
      p: 2,
      overflowY: "auto"
    }
  }, /*#__PURE__*/React.createElement(Typography, {
    variant: "h6",
    mb: 2
  }, "Settings"), /*#__PURE__*/React.createElement(List, null, menuItems.map(item => /*#__PURE__*/React.createElement(ListItemButton, {
    key: item.label,
    selected: item.label === activeMenu,
    sx: {
      borderRadius: 3,
      mb: 0.5,
      py: 1
    },
    onClick: () => setActiveMenu(item.label)
  }, /*#__PURE__*/React.createElement(ListItemIcon, null, item.icon), /*#__PURE__*/React.createElement(ListItemText, {
    primary: item.label
  }))))), /*#__PURE__*/React.createElement(Box, {
    sx: {
      flex: 1,
      p: 3,
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    onClick: onClose,
    sx: {
      position: "absolute",
      top: 16,
      right: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded"
  }, "close")), activeMenu === "Account" && /*#__PURE__*/React.createElement(ProfileSettings, null))));
}
function ProfileSettings() {
  const {
    user,
    setUser
  } = useContext(Context);
  const changePicture = () => {
    let input = document.createElement("input");
    input.type = 'file';
    input.accept = 'image/*';
    input.addEventListener('change', function (event) {
      //upload
      let formdata = new FormData();
      formdata.append("change_picture", input.files[0]);
      post("api/", formdata, function (response) {
        try {
          let res = JSON.parse(response);
          if (res.status) {
            setUser({
              ...user,
              picture: res.filename
            });
          }
        } catch (e) {
          alert(e.toString() + response);
        }
      });
    });
    input.click();
  };
  return /*#__PURE__*/React.createElement(Box, null, /*#__PURE__*/React.createElement(Typography, {
    variant: "h5",
    mb: 0.5
  }, "Profile"), /*#__PURE__*/React.createElement(Typography, {
    variant: "body2",
    color: "text.secondary",
    mb: 3
  }, "This is how you appear to others on the app."), /*#__PURE__*/React.createElement(Box, {
    sx: {
      display: "flex",
      alignItems: "center",
      mb: 3
    }
  }, /*#__PURE__*/React.createElement(Box, {
    sx: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    src: "../uploads/" + user.picture,
    sx: {
      width: 64,
      height: 64,
      bgcolor: "#f3e5f5",
      color: "#7b1fa2"
    }
  }, user.name?.charAt(0).toUpperCase()), /*#__PURE__*/React.createElement(IconButton, {
    size: "small",
    sx: {
      position: "absolute",
      bottom: -4,
      right: -4,
      bgcolor: "#fff",
      boxShadow: 1
    },
    onClick: changePicture
  }, /*#__PURE__*/React.createElement("span", {
    className: "material-symbols-rounded"
  }, "edit"))), /*#__PURE__*/React.createElement(Box, {
    sx: {
      ml: 3,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement(Typography, {
    variant: "subtitle2",
    mb: 0.5
  }, "Display Name"), /*#__PURE__*/React.createElement(TextField, {
    fullWidth: true,
    size: "small",
    value: user.name,
    onChange: e => setUser({
      ...user,
      name: e.target.value
    })
  }))), /*#__PURE__*/React.createElement(Typography, {
    variant: "subtitle2",
    mb: 0.5
  }, "Username"), /*#__PURE__*/React.createElement(TextField, {
    fullWidth: true,
    size: "small",
    value: user.email,
    onChange: e => setUser({
      ...user,
      email: e.target.value
    }),
    InputProps: {
      readOnly: true,
      endAdornment: /*#__PURE__*/React.createElement(IconButton, {
        size: "small"
      }, /*#__PURE__*/React.createElement("span", {
        className: "material-symbols-rounded"
      }, "content_copy"))
    }
  }), /*#__PURE__*/React.createElement(Typography, {
    variant: "subtitle2",
    mb: 0.5
  }, "Phone"), /*#__PURE__*/React.createElement(TextField, {
    fullWidth: true,
    size: "small",
    value: user.phone,
    onChange: e => setUser({
      ...user,
      phone: e.target.value
    }),
    InputProps: {
      readOnly: true,
      endAdornment: /*#__PURE__*/React.createElement(IconButton, {
        size: "small"
      }, /*#__PURE__*/React.createElement("span", {
        className: "material-symbols-rounded"
      }, "content_copy"))
    }
  }), /*#__PURE__*/React.createElement(Divider, {
    sx: {
      my: 3
    }
  }), /*#__PURE__*/React.createElement(Box, {
    sx: {
      display: "flex",
      gap: 2
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "contained",
    color: "inherit",
    startIcon: /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded"
    }, "open_in_new")
  }, "Manage account"), /*#__PURE__*/React.createElement(Button, {
    variant: "outlined",
    color: "error",
    startIcon: /*#__PURE__*/React.createElement("span", {
      className: "material-symbols-rounded"
    }, "logout")
  }, "Sign out")));
}