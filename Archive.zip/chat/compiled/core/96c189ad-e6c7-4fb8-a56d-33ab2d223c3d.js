const {
  useEffect,
  useState,
  useContext,
  createContext
} = React;
import { Context } from "../cd073e99-961c-4d8f-a678-bc0a129dfe7e.js";
export function Header() {
  const {
    friend,
    setFriend
  } = useContext(Context);
  return /*#__PURE__*/React.createElement("header", {
    className: "h-20 flex items-center justify-between px-6 border-b border-gray-100 bg-white/80 backdrop-blur-md sticky top-0 z-10"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center"
  }, /*#__PURE__*/React.createElement("button", {
    onclick: "toggleSidebar()",
    className: "md:hidden mr-4 text-gray-500 hover:text-gray-700 focus:outline-none"
  }, /*#__PURE__*/React.createElement("i", {
    className: "fas fa-bars text-xl"
  })), /*#__PURE__*/React.createElement("div", {
    className: "relative"
  }, /*#__PURE__*/React.createElement("img", {
    src: "../uploads/" + friend.picture,
    className: "w-10 h-10 rounded-full border border-gray-200",
    onError: e => {
      e.target.onerror = null;
      e.target.src = "../uploads/default_avatar.png";
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 border-2 border-white rounded-full"
  })), /*#__PURE__*/React.createElement("div", {
    className: "ml-4"
  }, /*#__PURE__*/React.createElement("h3", {
    className: "font-bold text-gray-800 text-lg leading-tight"
  }, friend.name), /*#__PURE__*/React.createElement("p", {
    className: "text-xs text-green-500"
  }, "Active now"))), /*#__PURE__*/React.createElement("div", {
    className: "flex items-center space-x-6 text-gray-400"
  }, /*#__PURE__*/React.createElement("button", {
    className: "hover:text-indigo-600 transition-colors"
  }, /*#__PURE__*/React.createElement("i", {
    className: "fas fa-phone-alt"
  })), /*#__PURE__*/React.createElement("button", {
    className: "hover:text-indigo-600 transition-colors"
  }, /*#__PURE__*/React.createElement("i", {
    className: "fas fa-video"
  })), /*#__PURE__*/React.createElement("button", {
    className: "hover:text-indigo-600 transition-colors"
  }, /*#__PURE__*/React.createElement("i", {
    className: "fas fa-info-circle"
  }))));
}